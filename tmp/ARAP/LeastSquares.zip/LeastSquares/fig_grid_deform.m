clear all; close all; clc;

Im = imread('loutre.jpg');

n = size(Im,1);
[x,y] = meshgrid(linspace(1,n,n),linspace(1,n,n));
X = [x(:), y(:)];
T = [(1:n-1)', (2:n)', n+(2:n)', n+(1:n-1)'];
T = repmat(vec(repmat((0:n-2)*n, [n-1,1])),[1,4]) + repmat(T, [n-1,1]);

figure;
% trisurf(T, X(:,1), X(:,2), zeros(n^2,1), 1);
image(Im);
axis equal; axis([1 n 1 n]);

%% Moving Least square
nv = size(X,1);
a = 2;
weight = @(X) sum(X.^2,length(size(X))).^(-a);

np = 5;
p = n*rand(np,2) + 1;
q = p + sqrt(n)*rand(np,2);

w_star = weight(cat(3, repmat(X(:,1),[1,np]) - repmat(p(:,1)',[nv,1]), repmat(X(:,2),[1,np]) - repmat(p(:,2)',[nv,1])));
p_star = (w_star*p) ./ repmat(sum(w_star,2), [1,2]);
q_star = (w_star*q) ./ repmat(sum(w_star,2), [1,2]);

A = zeros(nv,np);
Aq_star = zeros(nv,2);
for i = 1:nv
    Bj = zeros(2,2);
    for j = 1:np
        Bj = Bj + (p(j,:) - p_star(i,:))'*weight(p(j,:) - X(i,:))*(p(j,:) - p_star(i,:));
    end
    A(i,:) = (X(i,:) - p_star(i,:)) * (Bj\(repmat(weight(p - repmat(X(i,:),[np,1]))', [2,1]) .* (q - repmat(q_star(i,:),[np,1]))'));
    Aq_star(i,:) = A(i,:)*repmat(q_star(i,:),[np,1]);
end


X_deform = A*q - Aq_star + q_star;
X_deform = round(X_deform);
X_deform(X_deform < 1) = 1;
X_deform(X_deform > n) = n;

Im_deform = Im;
Im_deform(:,:,1) = reshape(Im(sub2ind([n,n,3], X_deform(:,2), X_deform(:,1), 1*ones(nv,1))),[n,n]);
Im_deform(:,:,2) = reshape(Im(sub2ind([n,n,3], X_deform(:,2), X_deform(:,1), 2*ones(nv,1))),[n,n]);
Im_deform(:,:,3) = reshape(Im(sub2ind([n,n,3], X_deform(:,2), X_deform(:,1), 3*ones(nv,1))),[n,n]);

figure;
subplot(1,2,1);
% trisurf(T, X(:,1), X(:,2), zeros(n^2,1), 1);
image(Im);
hold on;
plot3(q(:,1), q(:,2), zeros(np,1), 'xr');
quiver3(q(:,1), q(:,2), zeros(np,1), p(:,1)-q(:,1), p(:,2)-q(:,2), zeros(np,1), 0, 'r');
axis equal; axis([1 n 1 n]); view(0,90); axis off;

subplot(1,2,2);
% trisurf(T, X_deform(:,1), X_deform(:,2), zeros(n^2,1), 1);
image(Im_deform);
hold on;
plot3(p(:,1), p(:,2), zeros(np,1), 'xb');
axis equal; axis([1 n 1 n]); view(0,90); axis off;
