clear all; close all; clc;

[V,T] = readOBJ('diablo.obj');
nf = size(T,1);
nv = size(V,1);

id_lock = [1176; 1766; 382; 2384; 1779];
V_lock = V(id_lock,:) + [0,0,-0.5; 0,0,0.5; 0,0,-0.5; 0,0,0.5; 1.5,0,0];
id_free = setdiff((1:nv)', id_lock);

figure;
trisurf(T, V(:,1), V(:,2), V(:,3), 1);
hold on;
plot3(V(id_lock,1), V(id_lock,2), V(id_lock,3), 'xr');
quiver3(V(id_lock,1), V(id_lock,2), V(id_lock,3), V_lock(:,1)-V(id_lock,1), V_lock(:,2)-V(id_lock,2), V_lock(:,3)-V(id_lock,3), 0, 'r');
axis equal;

%% Compute cotangents Laplacian
normv = @(V) sqrt(sum(V.^2,2));
E1 = V(T(:,2),:)-V(T(:,3),:);
L1 = normv(E1);
E2 = V(T(:,1),:)-V(T(:,3),:);
L2 = normv(E2);
E3 = V(T(:,1),:)-V(T(:,2),:);
L3 = normv(E3);

EL = [L1,L2,L3];
A1 = (L2.^2 + L3.^2 - L1.^2) ./ (2.*L2.*L3);
A2 = (L1.^2 + L3.^2 - L2.^2) ./ (2.*L1.*L3);
A3 = (L1.^2 + L2.^2 - L3.^2) ./ (2.*L1.*L2);
A = [A1,A2,A3];
A = acos(A);
cotangents = abs(cot(A));

I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
S = 0.5*abs(cot([A(:,3);A(:,1);A(:,2)]));
In = [I;J;I;J];
Jn = [J;I;I;J];
Sn = [-S;-S;S;S];
cotLaplacian = sparse(In,Jn,Sn,nv,nv);

U = zeros(nv,3);
U(id_lock,:) = V_lock - V(id_lock,:);
U(id_free,:) = cotLaplacian(id_free,id_free) \ ( - cotLaplacian(id_free,id_lock)*U(id_lock,:));

V_lap = V + U;

figure;
trisurf(T, V_lap(:,1), V_lap(:,2), V_lap(:,3), 1);
axis equal;

%% As-rigid-as possible
V_prime = V_lap;
Rot = cell(nv,1);

tic;
maxIter = 200; % make a parameter some day...
for i = 1:maxIter
    fprintf('Iteration %d... ',i);
    
    % Now, estimate the rotations
    E1new = V_prime(T(:,2),:) - V_prime(T(:,3),:);
    E2new = V_prime(T(:,1),:) - V_prime(T(:,3),:);
    E3new = V_prime(T(:,1),:) - V_prime(T(:,2),:);
    
    for j = 1:nv
        Rot{j} = zeros(3,3);
    end
    for j = 1:nf
        Rot{T(j,3)} = Rot{T(j,3)} + cotangents(j,1)*E1(j,:)'*E1new(j,:);
        Rot{T(j,2)} = Rot{T(j,2)} + cotangents(j,1)*E1(j,:)'*E1new(j,:);
        
        Rot{T(j,3)} = Rot{T(j,3)} + cotangents(j,2)*E2(j,:)'*E2new(j,:);
        Rot{T(j,1)} = Rot{T(j,1)} + cotangents(j,2)*E2(j,:)'*E2new(j,:);
        
        Rot{T(j,2)} = Rot{T(j,2)} + cotangents(j,3)*E3(j,:)'*E3new(j,:);
        Rot{T(j,1)} = Rot{T(j,1)} + cotangents(j,3)*E3(j,:)'*E3new(j,:);
    end
    for j = 1:nv
        [Usvd,~,Vsvd] = svd(Rot{j});
        Rot{j} = Vsvd * Usvd';
        
        if det(Rot{j}) < 0
            Vsvd(:,3)=-Vsvd(:,3);
			Rot{j} = Vsvd * Usvd';
        end
    end
    
    % Do linear solve for the p' variables
    e1Rot = zeros(nf,3);
    e2Rot = zeros(nf,3);
    e3Rot = zeros(nf,3);
    for j = 1:nf
        e1Rot(j,:) = 0.5*((Rot{T(j,2)} + Rot{T(j,3)})*E1(j,:)')';
        e2Rot(j,:) = 0.5*((Rot{T(j,1)} + Rot{T(j,3)})*E2(j,:)')';
        e3Rot(j,:) = 0.5*((Rot{T(j,1)} + Rot{T(j,2)})*E3(j,:)')';
    end
    
    e1Rot = bsxfun(@times,e1Rot,cotangents(:,1));
    e2Rot = bsxfun(@times,e2Rot,cotangents(:,2));
    e3Rot = bsxfun(@times,e3Rot,cotangents(:,3));
    
    b = zeros(nv,3);
    o = ones(nf,1);
    for dim = 1:3
        b(:,dim) = b(:,dim) + accumarray([T(:,2) o], e1Rot(:,dim),[size(b,1) 1]);
        b(:,dim) = b(:,dim) + accumarray([T(:,3) o],-e1Rot(:,dim),[size(b,1) 1]);
        
        b(:,dim) = b(:,dim) + accumarray([T(:,1) o], e2Rot(:,dim),[size(b,1) 1]);
        b(:,dim) = b(:,dim) + accumarray([T(:,3) o],-e2Rot(:,dim),[size(b,1) 1]);
        
        b(:,dim) = b(:,dim) + accumarray([T(:,1) o], e3Rot(:,dim),[size(b,1) 1]);
        b(:,dim) = b(:,dim) + accumarray([T(:,2) o],-e3Rot(:,dim),[size(b,1) 1]);
    end
    b = 0.5*b;
    
    V_old = V_prime;
    V_prime(id_lock,:) = V_lock;
    V_prime(id_free,:) = cotLaplacian(id_free,id_free) \ (b(id_free,:) - cotLaplacian(id_free,id_lock)*V_lock);
    vertexChange = norm(V_prime(:) - V_old(:),'inf')/norm(V_prime,'inf');
    
    fprintf(' change = %g\n',vertexChange);
    if i > 5 && vertexChange < 1e-4 % .1% change
        break;
    end
end


figure;
trisurf(T, V_prime(:,1), V_prime(:,2), V_prime(:,3), 1);
axis equal;
